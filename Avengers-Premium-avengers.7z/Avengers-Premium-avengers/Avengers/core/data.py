from pyrogram.types import InlineKeyboardButton, WebAppInfo
from Avengers import CMD_HNDLR as cmds
class Data:

    text_help_menu = (
        f"**Menu Ngentot**\n** • Prefixes** : `Lo gila??`"
    )
    reopen = [[InlineKeyboardButton("Open", callback_data="reopen")]]
