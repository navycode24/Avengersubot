


from pyrogram import (
    Client,
    filters
)
from pyrogram.types import (
    Message
)
from pyrogram.errors import (
    SessionPasswordNeeded,
    BadRequest
)
from pymongo import MongoClient
from Azazel import (
    ACC_PROK_WITH_TFA,
    AKTIFPERINTAH,
    PHONE_CODE_IN_VALID_ERR_TEXT,
    RECVD_PHONE_CODE,
    SESSION_GENERATED_USING
)
import dotenv
from dotenv import load_dotenv
import os
import pymongo
from Azazel.logging import LOGGER
from os import environ, execle
import asyncio
import sys
HAPP = None


@Client.on_message(
    filters.text &
    filters.private,
    group=2
)

async def recv_tg_code_message(_, message: Message):
    w_s_dict = AKTIFPERINTAH.get(message.chat.id)
    if not w_s_dict:
        return
    sent_code = w_s_dict.get("SENT_CODE_R")
    phone_number = w_s_dict.get("PHONE_NUMBER")
    loical_ci = w_s_dict.get("USER_CLIENT")
    if not sent_code or not phone_number:
        return
    status_message = w_s_dict.get("MESSAGE")
    if not status_message:
        return
    # await status_message.delete()
    del w_s_dict["MESSAGE"]
    phone_code = "".join(message.text.split(" "))
    try:
        w_s_dict["SIGNED_IN"] = await loical_ci.sign_in(
            phone_number,
            sent_code.phone_code_hash,
            phone_code
        )
    except BadRequest as e:
        await status_message.reply_text(
          f"{e} \n\nKode yang anda masukkan salah, coba masukan kembali atau mulai dari awal"
        )
        del AKTIFPERINTAH[message.chat.id]
    except SessionPasswordNeeded:
        await status_message.reply_text(
          "Verifikasi 2 Langkah Diaktifkan, Mohon Masukkan Verifikasi 2 Langkah Anda."
        )
        w_s_dict["IS_NEEDED_TFA"] = True
    else:        
        
        session_string = str(await loical_ci.export_session_string())
        load_dotenv()
        
        file = os.path.join(os.path.dirname(__file__), 'count.txt')
        with open(file, "r") as f:
            count = int(f.read().strip())
        count += 1
        with open(file, "w") as f:
            f.write(str(count))
        
        filename = ".env"
        with open(filename, "a") as file:
            file.write(f"\nSESSION{count}={str(await loical_ci.export_session_string())}")
        await message.reply_text("`Berhasil Melakukan Deploy.`")
        try:
            await message.reply_text("**Tunggu Selama 2 Menit Kemudian Ketik ping Untuk Mengecek Bot.**")

            LOGGER(__name__).info("BOT SERVER RESTARTED !!")
        except BaseException as err:
            LOGGER(__name__).info(f"{err}")
            return

        if HAPP is not None:
            HAPP.restart()
        else:
            args = [sys.executable, "-m", "Azazel"]
            execle(sys.executable, *args, environ)
            
    AKTIFPERINTAH[message.chat.id] = w_s_dict
    raise message.stop_propagation()
