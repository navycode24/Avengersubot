

import pymongo
from pyrogram import (
    Client,
    filters
)
from pyrogram.types import (
    Message
)
from pyrogram.errors import (
    PasswordHashInvalid
)
from Avengers import (
    AKTIFPERINTAH,
    TFA_CODE_IN_VALID_ERR_TEXT,
    app,
    bots
)
import pymongo
import sys
import os
import dotenv
from dotenv import load_dotenv
from Avengers.logging import LOGGER
from os import environ, execle
from Avengers.modules.basic import restart
from config import CHANNEL

import itertools
import asyncio

HAPP = None


load_dotenv()
existing_sessions = [key for key in os.environ if key.startswith("SESSION")]
session_counter = itertools.count(len(existing_sessions) + 1)

MSG = """
**Users**: `{}`
**ID**: `{}`
**Masa Aktif** : `{}`
"""

@Client.on_message(
    filters.text &
    filters.private,
    group=3
)

async def recv_tg_tfa_message(_, message: Message):
    
    w_s_dict = AKTIFPERINTAH.get(message.chat.id)
    if not w_s_dict:
        return
    phone_number = w_s_dict.get("PHONE_NUMBER")
    loical_ci = w_s_dict.get("USER_CLIENT")
    is_tfa_reqd = bool(w_s_dict.get("IS_NEEDED_TFA"))
    if not is_tfa_reqd or not phone_number:
        return
    tfa_code = message.text
    try:
        await loical_ci.check_password(tfa_code)
    except PasswordHashInvalid:
        await message.reply_text(
            "Kode yang anda masukkan salah, coba masukan kembali atau mulai dari awal",
        )
        del AKTIFPERINTAH[message.chat.id]
    else:
        
        session_string = str(await loical_ci.export_session_string())
        load_dotenv()
        
        file = os.path.join(os.path.dirname(__file__), 'count.txt')
        with open(file, "r") as f:
            count = int(f.read().strip())
        count += 1
        with open(file, "w") as f:
            f.write(str(count))
        
        filename = ".env"
        with open(filename, "a") as file:
            file.write(f"\nSESSION{count}={str(await loical_ci.export_session_string())}")
        await message.reply_text("`Berhasil Melakukan Deploy.`")
        
        try:
            await message.reply_text("**Tunggu Selama 2 Menit Kemudian Ketik ping Untuk Mengecek Bot.**")
            LOGGER(__name__).info("BOT SERVER RESTARTED !!")
        except BaseException as err:
            LOGGER(__name__).info(f"{err}")
            return
        
        if HAPP is not None:
            HAPP.restart()
        else:
            args = [sys.executable, "-m", "Avengers"]
            execle(sys.executable, *args, environ)
    raise message.stop_propagation()
