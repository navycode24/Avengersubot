"""
Project [DarkWeb](https://github.com/TeamKillerX/DarkWeb) is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.

"""

TRUTH = [
    "Siapa pirst lope mu?"
    "Ngaku! Pernah curi duit orang tua ga?",
    "Berapa jumlah mantan lu?",
    "Ceritakan masalah paling kamu ingat saat di sekolah",
    "Pilih cowo ganteng atau cowo kaya? Tapi ga ganteng",
    "Apabila kamu cewe bersedia kah untuk menjadi pacar owner ku @kenapanan",
    "Momen paling paling terbaik menurut lu selama idup apa?",
    "Sebutkan 100 hal tentang teman kamu",
    "Pilih cewe cantik atau cewe jadi²an?",
    "Apa ketakutan yang paling besar menurut kamu?",
    "Ceritakan hal sebelum kamu putus sama pacar",
    "Tipe cewe idaman lu seperti apa? tete besarkah? Coba sebutkan seperti apa tipe lu",
    "Tipe cowo idaman kamu seperti apa?",
    "Coba tag orang yang paling kamu sayang disini.",
    "Hayoo, kapan terakhir kali kamu anu?",
    "Ceritakan kisah idup lu :')",
    "@kenapanan menurut ku dia ganteng, coba deh kamu chat, trus ajak pacaran hehe ⚠️WARNING ini khusus cewe ya!",
  
]

DARE = [
     "Tampilkan foto paling memalukan di ponsel Anda"
     "Tampilkan lima orang terakhir yang Anda kirimi chat dan apa isi pesannya",
     "Bilang, aku jelek 5 kali dengan voice note",
     "Makan bawang putih mentah",
     "Ratakan 100 squad di pubg atau free fire",
     "Simpan tiga es batu di mulutmu sampai meleleh",
     "Katakan sesuatu yang kotor kepada orang di sebelah kirimu. Kamu punya teman!",
     "Berikan pijatan kaki pada orang di sebelah kanan Anda",
     "Masukkan 10 cairan berbeda yang tersedia ke dalam cangkir dan minumlah",
     "Ucapkan kata pertama yang muncul di pikiranmu",
     "Berikan lap dance kepada seseorang pilihan Anda",
     "Lepaskan empat pakaian",
     "Suka 15 posting pertama di umpan berita Facebook Anda",
     "Makan sesendok garam",
     "Pejamkan matamu sampai kamu pergi lagi",
     "Kirim sex ke orang terakhir di kontak telepon Anda",
     "Pamerkan wajah orgasme Anda",
     "Makan pisang dengan menggoda",
     "Kosongkan dompet Anda dan tunjukkan kepada semua orang apa yang ada di dalamnya",
     "Lakukan perayapan seksi terbaikmu",
     "Berpura-puralah menjadi orang di sebelah kananmu selama 10 menit",
     "Makan camilan tanpa menggunakan tangan",
     "Katakan dua hal jujur ​​tentang semua orang dalam grup",
     "Twerk sebentar",
     "Cobalah membuat anggota grup tertawa secepat mungkin",
     "Cobalah untuk memasukkan seluruh kepalan tanganmu ke dalam mulutmu",
     "Ceritakan kepada semua orang kisah memalukan tentang dirimu",
     "Coba jilat sikumu",
     "Posting selfie tertua di ponsel Anda di Instagram Stories",
     "Ceritakan kisah paling menyedihkan yang kamu tahu",
     "Melolong seperti serigala selama dua menit",
     "Menari tanpa musik selama dua menit",
     "Tari tiang dengan tiang imajiner",
     "Biarkan orang lain menggelitikmu dan mencoba untuk tidak tertawa",
     "Masukkan makanan ringan ke dalam mulut Anda sekaligus sebanyak yang Anda bisa",
     "Kirim selfie terbaru Anda.",
     "Kirim selfie terjelekmu.",
     "Kirim tangkapan layar riwayat pencarian facebook Anda",
     "Kirim tangkapan layar galeri Anda.",
     "Kirim tangkapan layar kotak masuk messenger Anda",
     "Katakan sesuatu yang sangat intim.",
     "Kirim tangkapan layar kotak masuk twitter Anda",
     "Kirim tangkapan layar layar beranda Anda.",
     "Kirim cover lagu favoritmu. ",
     "Lakukan lelucon lirik pada seseorang dan kirimkan buktinya.",
     "Akui kalo lu naksir temen sekelas lu saat ini. ❤️",
     "Ungkapkan siapa cinta sejatimu.",
     "Kirim tangkapan layar galeri Anda.",
     "Jadikan gambar gebetanmu sebagai wallpaper chat.",
     "Bilang ke @rencprx bahwa dia ganteng",
]

AP = ["Iya", 
                 "Tidak", 
                 "Mungkin", 
                 "Mungkin Tidak", 
                 "Bisa jadi", 
                 "Mungkin Tidak",
                 "Tidak Mungkin",
                 "Harus banget gua jawab?",
                 "Apaansi nanya mulu lu",
                 "Emang bener?",
                 "Mana gua tau ",
                 "Lu tanya gua, terus gua tanya siapa?",
                 "Nanya Mulu lu"
                 ]
                 
KN = ["Iya", 
                 "Kaga Tau Ya", 
                 "Kok Nanya Gue", 
                 "Nanya Apaan", 
                 "Tanya Emak Lu", 
                 "Tanya Bokap Lu Coba",
                 "Karena Lu Belom Mandi",
                 "Harus banget gua jawab?",
                 "Apaansi nanya mulu lu",
                 "Emang bener?",
                 "Mana gua tau ",
                 "Lu tanya gua, terus gua tanya siapa?",
                 "Nanya Mulu lu"
                 "Karna Kamu Jamet"
                 ]
                 
BG = ["Tau ya", 
                 "Lah Au Ya ?", 
                 "Mandi Aer Got", 
                 "Diem Jamet", 
                 "Berisik lu", 
                 "Bacot",
                 "Astaghfirullah, Anj",
                 "Kan Udah Dibilang Jangan Budeg",
                 "Apaansi nanya mulu lu",
                 "Emang bener?",
                 "Mana gua tau ",
                 "Hahahaah, Au Ya?",
                 "Mending Diem"
                 ]

